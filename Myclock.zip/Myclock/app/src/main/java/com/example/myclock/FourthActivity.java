package com.example.myclock;

import java.util.Timer;
import java.util.TimerTask;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.os.Bundle;
import android.widget.TextView;
public class FourthActivity extends TittleActivity  {

    private TextView tvHour,tvMin,tvSec,tvMsec;
    private Button btnStart,btnPause,btnResume,btnReset,btnLap;
    private ListView lvTimeList;
    private ArrayAdapter<String> adapter;
    private int tenMSecs = 0;
    private Timer timer =new Timer();
    private TimerTask timerTask = null;
    private TimerTask showTimerTask = null;
    private static final int MSG_WHAT_SHOW_TIME = 1;
    public Context a=FourthActivity.this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fourth_layout);

        method(a);
        Button button4=(Button)findViewById(R.id.button_4);
        button4.setBackgroundColor(Color.GRAY);
        tvHour = (TextView) findViewById(R.id.timeHour);
        tvMin = (TextView) findViewById(R.id.timeMin);
        tvSec = (TextView) findViewById(R.id.timeSec);
        tvMsec = (TextView) findViewById(R.id.timeMsec);
        tvHour.setText("00");
        tvMin.setText("00");
        tvSec.setText("00");
        tvMsec.setText("00");

        btnStart = (Button) findViewById(R.id.btnSWStart);
        btnPause = (Button) findViewById(R.id.btnSWPause);
        btnResume = (Button) findViewById(R.id.btnSWResume);
        btnLap = (Button) findViewById(R.id.btnSWLap);
        btnReset = (Button) findViewById(R.id.btnSWReset);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTimer();
                btnStart.setVisibility(View.GONE);
                btnPause.setVisibility(View.VISIBLE);
                btnLap.setVisibility(View.VISIBLE);
            }
        });
        btnPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopTimer();
                btnPause.setVisibility(View.GONE);
                btnResume.setVisibility(View.VISIBLE);
                btnLap.setVisibility(View.GONE);
                btnReset.setVisibility(View.VISIBLE);
            }
        });
        btnResume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTimer();
                btnResume.setVisibility(View.GONE);
                btnPause.setVisibility(View.VISIBLE);
                btnLap.setVisibility(View.VISIBLE);
                btnReset.setVisibility(View.GONE);
            }
        });
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopTimer();
                tenMSecs = 0;
                adapter.clear();
                btnReset.setVisibility(View.GONE);
                btnLap.setVisibility(View.GONE);
                btnPause.setVisibility(View.GONE);
                btnResume.setVisibility(View.GONE);
                btnStart.setVisibility(View.VISIBLE);
            }
        });
        btnLap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.insert(String.format("%d:%d:%d.%d", tenMSecs/100/60/60,tenMSecs/100/60%60,tenMSecs/100%60,tenMSecs%100), 0);
            }
        });
        btnLap.setVisibility(View.GONE);
        btnPause.setVisibility(View.GONE);
        btnResume.setVisibility(View.GONE);
        btnReset.setVisibility(View.GONE);
        lvTimeList = (ListView) findViewById(R.id.lvWatchTime);
        adapter = new ArrayAdapter<String>(FourthActivity.this, android.R.layout.simple_list_item_1);
        lvTimeList.setAdapter(adapter);
        showTimerTask = new TimerTask() {
            @Override
            public void run() {
                handle.sendEmptyMessage(MSG_WHAT_SHOW_TIME);
            }
        };
        timer.schedule(showTimerTask, 100, 100);
    }
    private void startTimer(){
        if (timerTask == null) {
            timerTask = new TimerTask() {
                @Override
                public void run() {
                    tenMSecs++;
                }
            };

            timer.schedule(timerTask, 0, 10);
        }
    }
    private void stopTimer(){
        if (timerTask != null) {
            timerTask.cancel();
            timerTask = null;
        }
    }
    @SuppressLint("HandlerLeak")
    private Handler handle = new Handler(){
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case MSG_WHAT_SHOW_TIME:
                    tvHour.setText(tenMSecs/100/60/60+"");
                    tvMin.setText(tenMSecs/100/60%60+"");
                    tvSec.setText(tenMSecs/100%60+"");
                    tvMsec.setText(tenMSecs%100+"");
                    break;

                default:
                    break;
            }
        };
    };
    public void onDestroy() {
        super.onDestroy();
        timer.cancel();
    }
}
