package com.example.myclock;

import androidx.appcompat.app.AlertDialog;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.Timer;
import java.util.TimerTask;

public class ThirdActivity extends TittleActivity {

    public Context a =ThirdActivity.this;
    private EditText Hour,Min,Sec;
    private Button SWstart,SWpause,SWreset;
    private static final int MSG_WHAT_TIME_IS_UP = 1;
    private static final int MSG_WHAT_TIME_TICK = 2;
    private int allTimeCount = 0;
    private Timer timer = new Timer();
    private TimerTask timerTask = null;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.third_layout);

        method(a);
        Button button3=(Button)findViewById(R.id.button_3);
        button3.setBackgroundColor(Color.GRAY);
        SWstart=(Button) findViewById(R.id.SWStart);
        SWpause=(Button) findViewById(R.id.SWPause);
        SWreset=(Button)findViewById(R.id.SWResume);

        SWstart.setOnClickListener( new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                startTime();
                SWstart.setVisibility(View.GONE);
                SWpause.setVisibility(View.VISIBLE);
                SWreset.setVisibility(View.VISIBLE);
            }
        });
        SWpause.setOnClickListener( new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                stopTime();
                SWpause.setVisibility(View.GONE);
                SWstart.setVisibility(View.VISIBLE);
                SWreset.setVisibility(View.VISIBLE);
            }
        });
        SWreset.setOnClickListener( new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                stopTime();
                Hour.setText("00");
                Min.setText("00");
                Sec.setText("00");
                SWpause.setVisibility(View.GONE);
                SWstart.setVisibility(View.VISIBLE);
                SWreset.setVisibility(View.GONE);
            }
        });
        Hour=(EditText)findViewById(R.id.Hour);
        Min=(EditText)findViewById(R.id.Min);
        Sec=(EditText)findViewById(R.id.Sec);

        SWstart.setVisibility(View.VISIBLE);
        SWstart.setEnabled(true);           //让控件可用
        SWpause.setVisibility(View.GONE);
        SWreset.setVisibility(View.GONE);

        Hour.setText("00");
        Hour.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            //这个方法是在Text改变之前被调用，它的意思就是说在原有的文本s中，从start开始的count个字符将会被一个新的长度为after的文本替换，注意这里是将被替换，还没有被替换。
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            //这个方法是在Text改变过程中触发调用的，它的意思就是说在原有的文本s中，从start开始的count个字符替换长度为before的旧文本，
                if (!TextUtils.isEmpty(s)) {

                    int value = Integer.parseInt(s.toString());

                    if (value > 59) {
                        Hour.setText("59");
                    } else if (value < 0) {
                        Hour.setText("00");
                    }
                }
                checkToEnableBtnStart();
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });
        Min.setText("00");
        Min.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());
                    if (value > 59) {
                        Min.setText("59");
                    } else if (value < 0) {
                        Min.setText("00");
                    }
                }
                checkToEnableBtnStart();
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        Sec.setText("00");
        Sec.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());
                    if (value > 59) {
                        Sec.setText("59");
                    } else if (value < 0) {
                        Sec.setText("00");
                    }
                }
                checkToEnableBtnStart();
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
    private void checkToEnableBtnStart() {
        SWstart.setEnabled((!TextUtils.isEmpty(Hour.getText()) && Integer
                .parseInt(Hour.getText().toString()) > 0)
                || (!TextUtils.isEmpty(Min.getText()) && Integer
                .parseInt(Min.getText().toString()) > 0)
                || (!TextUtils.isEmpty(Sec.getText()) && Integer
                .parseInt(Sec.getText().toString()) > 0));
    }
    private void startTime(){
        if (timerTask == null) {
            allTimeCount = Integer.parseInt(Hour.getText().toString()) * 60
                    * 60 + Integer.parseInt(Min.getText().toString()) * 60
                    + Integer.parseInt(Sec.getText().toString());
            timerTask = new TimerTask() {

                @Override
                public void run() {
                    allTimeCount--;
                    handle.sendEmptyMessage(MSG_WHAT_TIME_TICK);
                    if (allTimeCount <= 0) {
                        handle.sendEmptyMessage(MSG_WHAT_TIME_IS_UP);
                        stopTime();
                    }
                }
            };
            timer.schedule(timerTask, 1000, 1000);
        }
    }
    private void stopTime(){
        if (timerTask!=null) {
            timerTask.cancel();
            timerTask=null;
        }
    };
    @SuppressLint("HandlerLeak")
    private Handler handle = new Handler() {

        @SuppressLint("SetTextI18n")
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case MSG_WHAT_TIME_TICK:
                    int hour = allTimeCount / 60 / 60;
                    int min = (allTimeCount / 60) % 60;
                    int sec = allTimeCount % 60;
                    Hour.setText(hour + "");
                    Min.setText(min + "");
                    Sec.setText(sec + "");
                    break;
                case MSG_WHAT_TIME_IS_UP:
                    new AlertDialog.Builder(ThirdActivity.this)
                            .setTitle("Time is up!")
                            .setMessage("Time is up!")
                            .setNegativeButton("Cancle", null).show();
                    SWreset.setVisibility(View.GONE);
                    SWpause.setVisibility(View.GONE);
                    SWstart.setVisibility(View.VISIBLE);
                    break;
                default:
                    break;
            }
        }

    };

}
