package com.example.myclock;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Bundle;
import static com.example.myclock.R.raw.music;
public class PlayAlarmActivity extends AppCompatActivity {
    private MediaPlayer mediaPlayer=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_layout);

        mediaPlayer= MediaPlayer.create(this, music);
        mediaPlayer.start();

        AlertDialog.Builder dialog=new AlertDialog.Builder(PlayAlarmActivity.this);
        dialog.setTitle("到点了");
        dialog.setMessage("闹钟响了");
        dialog.setCancelable(false);
        dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mediaPlayer.stop();
                finish();
            }

        });
        dialog.show();
    }

}
