package com.example.myclock;
import java.util.Calendar;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TimePicker;
import android.os.Bundle;

public class SecondActivity extends TittleActivity {

    private Button btnAddAlarm;
    private ListView lvListAlarm;
    private ArrayAdapter<AlarmData> adapter;
    private AlarmManager alarmManager;
    public Context a=SecondActivity.this;
    private  void init() {
        alarmManager = (AlarmManager) SecondActivity.this.getSystemService(
                Context.ALARM_SERVICE);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_layout);

        method(a);
        Button button1=(Button)findViewById(R.id.button_1);
        button1.setBackgroundColor(Color.GRAY);
        btnAddAlarm = (Button) findViewById(R.id.btnAddAlarm);
        lvListAlarm = (ListView) findViewById(R.id.lvListAlarm);
        adapter = new ArrayAdapter<AlarmData>(SecondActivity.this,
                android.R.layout.simple_list_item_1);
        lvListAlarm.setAdapter(adapter);
        readSaveAlarmList();
        btnAddAlarm.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                addAlarm();
            }
        });
        lvListAlarm.setOnItemLongClickListener(new OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                                           final int position, long arg3) {

                new AlertDialog.Builder(SecondActivity.this)
                        .setTitle("操作选项")
                        .setItems(new CharSequence[] { "删除" },
                                new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int which) {
                                        switch (which) {
                                            case 0:
                                                deleteAlarm(position);
                                                break;

                                            default:
                                                break;
                                        }
                                    }
                                }).setNegativeButton("取消", null).show();
                return true;
            }
        });
    }
    private void deleteAlarm(int position) {
        AlarmData ad = adapter.getItem(position);
        adapter.remove(ad);
        saveAlarmList();

        alarmManager.cancel(PendingIntent.getBroadcast(SecondActivity.this,
                ad.getId(), new Intent(SecondActivity.this, AlarmReceiver.class), 0));
    }

    private void addAlarm() {
        SecondActivity.this.init();

        final Calendar c = Calendar.getInstance();

        new TPDiolog(SecondActivity.this, AlertDialog.THEME_HOLO_LIGHT,new TimePickerDialog.OnTimeSetListener() {

            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {   //TimePicker时间选择器

                Calendar calendar = Calendar.getInstance();

                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                calendar.set(Calendar.MINUTE, minute);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);

                Calendar currentTime = Calendar.getInstance();
                if (currentTime.getTimeInMillis() >= calendar.getTimeInMillis()) { //java.util.Calendar.getTimeInMillis() 方法返回此baiCalendar以毫秒为单位的时间
                    calendar.setTimeInMillis(calendar.getTimeInMillis() + 24    //获取到日期的毫秒显示形式
                            * 60 * 60 * 1000);
                }

                AlarmData ad = new AlarmData(calendar.getTimeInMillis());
                adapter.add(ad);
                alarmManager.setRepeating(  //setRepeating(int type，long startTime，long intervalTime，PendingIntent pi)
                                                                    //用于设置一次性闹钟
                        AlarmManager.RTC_WAKEUP, ad.getTime(), 24*60*60*1000,PendingIntent  //AlarmManager.RTC_WAKEUP，硬件闹钟，当闹钟发躰时唤醒手机休眠；
                                .getBroadcast(SecondActivity.this, ad.getId(),
                                        new Intent(SecondActivity.this,AlarmReceiver.class    //参数PendingIntent pi： 绑定了闹钟的执行动作，比如发送一个广播、给出提示等等
                                                ), 0));
                saveAlarmList();
            }
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
        //TimePickerDialog方法有五个参数，第一个参数（MenuView.this）为弹出的时间对话框所在的activity指针；第二个参数我们最后说；第三个参数（hour）和
        // 第四个参数（minute）为弹出的时间对话框的初始显示的小时和分钟，这两个变量在蓝色代码中进行初始化；第五个参数为设置24时显示参数，true代表时间以24时制显示时间。
    }
    private static final String KEY_ALARM_LIST = "alarmlist";

    private void saveAlarmList() {
        Editor editor = SecondActivity.this.getSharedPreferences(
                SecondActivity.class.getName(), Context.MODE_PRIVATE).edit();

        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < adapter.getCount(); i++) {
            sb.append(adapter.getItem(i).getTime()).append(",");

        }
        if (sb.length() > 1) {
            String content = sb.toString().substring(0, sb.length() - 1);
            editor.putString(KEY_ALARM_LIST, content);

            System.out.println(content);
        } else {
            editor.putString(KEY_ALARM_LIST, null);
        }
        editor.commit();
    }

    private void readSaveAlarmList() {
        SharedPreferences sp = SecondActivity.this.getSharedPreferences(
                SecondActivity.class.getName(), Context.MODE_PRIVATE);
        String content = sp.getString(KEY_ALARM_LIST, null);

        if (content != null) {
            String[] timeStrings = content.split(",");
            for (String string : timeStrings) {
                adapter.add(new AlarmData(Long.parseLong(string)));
            }
        }
    }
    private static class AlarmData {
        private long time = 0;
        private Calendar date;
        private String timeLabel ;

        @SuppressLint("DefaultLocale")
        public AlarmData(long time) {
            this.time = time;
            date = Calendar.getInstance();
            date.setTimeInMillis(time);
            timeLabel = String.format("%d月%d日   %d:%d",
                    date.get(Calendar.MONTH) + 1,
                    date.get(Calendar.DAY_OF_MONTH),
                    date.get(Calendar.HOUR_OF_DAY), date.get(Calendar.MINUTE));
        }

        public long getTime() {
            return time;
        }

        public String getTimeLabel() {
            return timeLabel;
        }

        public int getId() {
            return (int) (getTime() / 1000 / 60);
        }

        @Override
        public String toString() {
            return getTimeLabel();
        }
    }
}
