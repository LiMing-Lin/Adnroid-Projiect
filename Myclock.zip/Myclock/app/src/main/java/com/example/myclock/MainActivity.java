package com.example.myclock;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Button;
import android.widget.TextView;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends TittleActivity {
    private TextView tvTime;
    private Timer timer;
    private Calendar mCalendar;
    public Context a = MainActivity.this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_layout);
        super.method(a);
        Button button2=(Button)findViewById(R.id.button_2);
        button2.setBackgroundColor(Color.GRAY);
        timer = new Timer();//创建定时器
        tvTime=findViewById(R.id.tvTime);
        timer.schedule(new TimerTask() {
            public void run() {
                mCalendar = Calendar.getInstance();//创建这个类的实例
                int hour = mCalendar.get(Calendar.HOUR_OF_DAY);//HOUR    进制为12小时   HOUR_OF_DAY  为24小时
                int minute = mCalendar.get(Calendar.MINUTE);//分钟
                int second = mCalendar.get(Calendar.SECOND) ;//秒数

                String time = String.format("%d:%02d:%02d", hour, minute, second);
                Message message = new Message();
                message.what = 0;
                message.obj = time;
                mHandler.sendMessage(message);
            }
        },0,1000);
    }
    @SuppressLint("HandlerLeak")
    Handler mHandler=new Handler(){
        @Override
        public void handleMessage(Message msg) {

            super.handleMessage(msg);
            String str=(String)msg.obj;
            tvTime.setText(str);
        }
    };
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(timer!=null){
            timer.cancel();//关闭timer
        }
    }
}
